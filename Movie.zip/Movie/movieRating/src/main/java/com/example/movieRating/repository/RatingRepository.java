package com.example.movieRating.repository;

import com.example.movieRating.models.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RatingRepository extends JpaRepository<Rating, String> {
    public Rating findByMovieId(String movieId);
}
