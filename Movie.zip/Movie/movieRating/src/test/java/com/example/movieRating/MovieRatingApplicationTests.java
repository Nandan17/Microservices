package com.example.movieRating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRatingApplicationTests {

	@Test
	void contextLoads() {
	}

}
