package com.example.movieGateway.controller;

import com.example.movieGateway.models.Catalog;
import com.example.movieGateway.models.Movie;
import com.example.movieGateway.models.Rating;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/catalog")
public class MovieCatalogcontroller {

    @RequestMapping("/{movieId}")
    public Catalog getCatalog(@PathVariable String movieId) {
        RestTemplate restTemplate = new RestTemplate();
        Movie movie = restTemplate.getForObject("http://localhost:3001/movies/get/" + movieId, Movie.class);
        Rating rating = restTemplate.getForObject("http://localhost:3002/rating/getrating/" + movieId, Rating.class);
        return new Catalog(movie.getName(), movie.getDescription(), rating.getRating(), movie.getMovieId());

    }

}
