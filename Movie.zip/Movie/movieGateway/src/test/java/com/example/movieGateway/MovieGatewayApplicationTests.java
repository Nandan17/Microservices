package com.example.movieGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
