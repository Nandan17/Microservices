package com.example.movieInfo.repository;

import com.example.movieInfo.models.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MovieInfoRepository extends JpaRepository<Movie, String> {
}
