package com.example.MG.models;

public class M1 {

    private String stdId;
    private String name;
    private String college;

    public M1() {

    }

    public M1(String stdId, String name, String college) {
        this.stdId = stdId;
        this.name = name;
        this.college = college;
    }

    public String getStudentId() {
        return stdId;
    }

    public void setMovieId(String stdId) {
        this.stdId = stdId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }
}
