package com.example.MG.models;

public class M12 {
    private String name;
    private String college;
    private String course;
    private String stdId;

    public M12() {

    }

    public M12(String name, String college, String course, String stdId) {
        this.name = name;
        this.college = college;
        this.course = course;
        this.stdId = stdId;
    }

    public void setStudentId(String stdId) {
        this.stdId = stdId;
    }

    public String getStudentId() {
        return stdId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course= course;
    }
}
