package com.example.M2.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Entity
@Table
public class M2 {

    @Id
    private String cId;
    @Column
    private String stdId;
    @Column
    private String course;

    public M2() {

    }

    public M2(String classBId, String classAId, String rating) {
        this.cId = cId;
        this.stdId = stdId;
        this.course = course;
    }

    public String getStudentId() {
        return stdId;
    }

    public void setStudentId(String stdId) {
        this.stdId = stdId;
    }

    public String getRid() {
        return cId;
    }

    public void setRid(String cId) {
        this.cId = cId;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}
